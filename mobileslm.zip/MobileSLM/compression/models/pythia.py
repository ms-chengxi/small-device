from transformers import AutoTokenizer  # , GPTNeoXForCausalLM
from peft import get_peft_model, LoraConfig
from gpt_neox import GPTNeoXForCausalLM


model = GPTNeoXForCausalLM.from_pretrained(
    "EleutherAI/pythia-70m-deduped",
    revision="step3000",
    cache_dir="./pythia-70m-deduped/step3000",
)

tokenizer = AutoTokenizer.from_pretrained(
    "EleutherAI/pythia-70m-deduped",
    revision="step3000",
    cache_dir="./pythia-70m-deduped/step3000",
)

inputs = tokenizer("Hello, I am", return_tensors="pt")
tokens = model.generate(**inputs)
output = tokenizer.decode(tokens[0])
print(output)


# reinitialize the model weights
# layers_to_reset = [(2, 3), (2, 4)]
# for layer in layers_to_reset:
#    for key in model.gpt_neox.layers[layer[1]].state_dict().keys():
#        model.gpt_neox.layers[layer[1]].state_dict()[key] = model.gpt_neox.layers[layer[0]].state_dict()[key]

# removing layers
layers_to_remove = [3, 4]
for i, layer in enumerate(layers_to_remove):
    model.gpt_neox.layers.pop(layer - i)

# lora target modules
lora_target_modules = ["gpt_neox.layers.{}.mlp.dense_h_to_4h".format(layer) for layer in layers_to_remove]
lora_target_modules.extend(["gpt_neox.layers.{}.mlp.dense_4h_to_h".format(layer) for layer in layers_to_remove])
print("LoRA target modules: ", lora_target_modules)
lora_rank = 200
lora_alpha = lora_rank * 2

lora_config = LoraConfig(
    layer_replication=[[0, 3], [2, 3], [2, 3], [3, 4]],
    init_lora_weights="pissa",
    r=8,
    lora_alpha=1,
    target_modules=lora_target_modules,
    lora_dropout=0.1,
)
peft_model = get_peft_model(model, lora_config)
