
from argparse import Namespace

import data_utils
from gpt_neox import GPTNeoXForCausalLM

# Usage
from peft import LoraConfig, get_peft_model
from transformers import (
    AutoTokenizer,
)
from utils import CurriculumTrainer
import torch
import gpu_utils


def collate_fn(batch):
    # Separate the different items in the batch
    input_ids = torch.stack([torch.tensor(item['input_ids']) for item in batch], axis=0)
    attention_masks = torch.stack([torch.tensor(item['attention_mask']) for item in batch], axis=0)
    labels = torch.stack([torch.tensor(item['labels']) for item in batch], axis=0)
    
    # # Pad the input_ids and attention_masks
    # input_ids = pad_sequence(input_ids, batch_first=True, padding_value=0)
    # attention_masks = pad_sequence(attention_masks, batch_first=True, padding_value=0)
    
    # Convert labels to tensor
    # labels = torch.tensor(labels)
    
    # Create the final dictionary
    return {
        'input_ids': input_ids,
        'attention_mask': attention_masks,
        'labels': labels
    }

if __name__ == "__main__":
    dataset = data_utils.get_dataset("wikitext2")

    model = GPTNeoXForCausalLM.from_pretrained(
        "EleutherAI/pythia-70m-deduped",
        revision="step3000",
        cache_dir="./pythia-70m-deduped/step3000",
    )

    model2 = GPTNeoXForCausalLM.from_pretrained(
        "EleutherAI/pythia-70m-deduped",
        revision="step3000",
        cache_dir="./pythia-70m-deduped/step3000",
    )

    tokenizer = AutoTokenizer.from_pretrained(
        "EleutherAI/pythia-70m-deduped",
        revision="step3000",
        cache_dir="./pythia-70m-deduped/step3000",
    )

    # removing layers
    layers_to_remove = [3, 4]
    for i, layer in enumerate(layers_to_remove):
        model2.gpt_neox.layers.pop(layer - i)

    # lora target modules
    lora_target_modules = ["gpt_neox.layers.{}.mlp.dense_h_to_4h".format(layer) for layer in layers_to_remove]
    lora_target_modules.extend(["gpt_neox.layers.{}.mlp.dense_4h_to_h".format(layer) for layer in layers_to_remove])
    print("LoRA target modules: ", lora_target_modules)
    lora_rank = 1200

    lora_config = LoraConfig(
        layer_replication=[[0, 3], [2, 3], [2, 3], [3, 4]],
        init_lora_weights="pissa",
        r=lora_rank,
        lora_alpha=1,
        target_modules=lora_target_modules,
        lora_dropout=0.1,
    )
    peft_model = get_peft_model(model2, lora_config)

    train_config = {
        "learning_rate": 5e-3,
        "adam_beta1": 0.9,
        "adam_beta2": 0.999,
        "adam_epsilon": 1e-8,
        "weight_decay": 0.01,
        "num_warmup_steps": 100,
        "lr_scheduler_type": "linear_with_warmup",
        "finetune_train_batch_size": 16,
        "device": "cuda",
        "epochs": 10,
        "gradient_accumulation_steps": 1,
        "finetune_train_seqlen": 1024,
        "finetune_train_nsamples": 1000,
        "varied_seqlen": False,
        "seed": 42,
    }

    train_config = Namespace(**train_config)

    train_dataset = dataset["train"]
    test_dataset = dataset["test"]
    tokenizer.pad_token = tokenizer.eos_token

    ppl_eval_loader = data_utils.prepare_dataloader(
        dataset=test_dataset,
        tokenizer=tokenizer,
        max_seqlen=128,
        batch_size=1,
        nsamples=16,
        varied_seqlen=True,
        seed=42,
        collate_fn=collate_fn
    )

    # for i in ppl_eval_loader:
    #     print(i)
    # compute perplexity before finetuning
    model.eval()
    model.to("cuda")
    dataset_ppl = gpu_utils.evaluate_ppl(
        model,
        torch.device("cuda"),
        model.config.pad_token_id,
        ppl_eval_loader,
    )
    print(f"PPL before finetuning: {dataset_ppl:.4f}")
    model.to("cpu")

    finetune_train_loader = data_utils.prepare_dataloader(
        dataset=train_dataset,
        tokenizer=tokenizer,
        max_seqlen=train_config.finetune_train_seqlen,
        batch_size=train_config.finetune_train_batch_size,
        nsamples=train_config.finetune_train_nsamples,
        varied_seqlen=train_config.varied_seqlen,
        seed=train_config.seed,
    )



    trainer = CurriculumTrainer(
        predessor=model,
        successor=peft_model,
        train_config=train_config,
        replacement_rate=0.2,
        k=1 / (len(finetune_train_loader) * train_config.epochs),
    )
    trainer.train(finetune_train_loader)
