# DeltaGPT



## Installation



## Quick Start
To run the curriculum training call [run_curriculum_training.py](compression/models/run_curriculum_training.py) in compression/models 


## Documentation



## Contributing



## License



## Contact

