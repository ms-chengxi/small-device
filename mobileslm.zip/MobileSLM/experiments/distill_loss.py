import torch
from torch.nn import functional as F
from transformers import Trainer


def distillation_loss(student_logits, teacher_logits):
    # Calculate the distillation loss
    dist_loss = F.kl_div(
        F.log_softmax(student_logits.view(-1, student_logits.size(-1)), dim=-1),
        F.softmax(teacher_logits.view(-1, teacher_logits.size(-1)), dim=-1),
        reduction="batchmean",
    )
    return dist_loss


class DistillationTrainer(Trainer):
    def __init__(self, student_model, teacher_model, *args, **kwargs):
        super().__init__(student_model, *args, **kwargs)
        self.student_model = student_model
        self.teacher_model = teacher_model
        self.teacher_model.eval()

    def compute_loss(self, model, inputs, return_outputs=False):
        if "labels" in inputs:
            labels = inputs["labels"]
        else:
            labels = None
        # Forward pass with the student model
        outputs = model(**inputs, output_hidden_states=True)

        # Save past state if it exists
        if self.args.past_index >= 0:
            self._past = outputs[self.args.past_index]

        if labels is not None:
            # Forward pass with the teacher model
            with torch.no_grad():
                outputs_teacher = self.teacher_model(**inputs, output_hidden_states=True)
                loss = outputs.loss  # loss from labels
                for stu_hstate, teach_hstate in zip(
                    outputs.hidden_states, outputs_teacher.hidden_states
                ):  # Add loss from hidden states
                    loss += distillation_loss(stu_hstate, teach_hstate)

        else:
            if isinstance(outputs, dict) and "loss" not in outputs:
                raise ValueError(
                    "The model did not return a loss from the inputs, only the following keys: "
                    f"{','.join(outputs.keys())}. For reference, the inputs it received are {','.join(inputs.keys())}."
                )
            # We don't use .loss here since the model may return tuples instead of ModelOutput.
            loss = outputs["loss"] if isinstance(outputs, dict) else outputs[0]

        return (loss, outputs) if return_outputs else loss
