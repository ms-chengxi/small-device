import logging
from argparse import Namespace
from copy import deepcopy

import numpy as np
import torch
import torch.nn as nn
import transformers
from rich.console import Console
from rich.logging import RichHandler
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeRemainingColumn,
)
from rich.theme import Theme
from torch.utils.data import DataLoader
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    GPTNeoXForCausalLM,
    Trainer,
)

LOGFORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
LOGFORMAT_RICH = "%(message)s"

# setup logging
# Create a custom theme for Rich
custom_theme = Theme(
    {
        "info": "cyan",
        "warning": "yellow",
        "error": "bold red",
        "critical": "bold white on red",
    }
)

# Create a Rich console with the custom theme
console = Console(theme=custom_theme)

# Configure the root logger to WARNING
logging.basicConfig(
    level=logging.WARNING,  # Set the root logger to WARNING
    format=LOGFORMAT_RICH,
    datefmt="[%X]",
    handlers=[RichHandler(console=console, rich_tracebacks=True)],
)


def create_custom_progress_bar(
    console: Console = None,
    color: str = "cyan",
    show_time: bool = True,
    show_spinner: bool = True,
    spinner_style: str = "dots",
) -> Progress:
    """
    Create a custom progress bar using Rich, optionally including loss reporting.

    :param description: Description of the task
    :param total: Total number of steps
    :param console: Rich Console object (if None, a new one will be created)
    :param color: Color of the progress bar
    :param show_time: Whether to show the time remaining
    :param show_spinner: Whether to show a spinner
    :param spinner_style: Style of the spinner (e.g., "dots", "dots12", "line", "arrow")
    :param show_loss: Whether to show loss information
    :return: A Rich Progress object and task ID
    """
    if console is None:
        console = Console()
    columns = []

    if show_spinner:
        columns.append(SpinnerColumn(spinner_name=spinner_style, style=color))

    columns.extend(
        [
            TextColumn("[bold blue]{task.description}", justify="right"),
            BarColumn(bar_width=None, style=color, complete_style=f"bold {color}"),
            TaskProgressColumn(),
            TextColumn(
                "[bold yellow]Epoch: {task.fields[epoch]} Loss: {task.fields[loss]:.4f} Avg Loss: {task.fields[avg_loss]:.4f} Replacement prob:{task.fields[replacement_prob]:.2f} lr:{task.fields[lr]:.8f}",
                justify="right",
            ),
        ]
    )

    if show_time:
        columns.append(TimeRemainingColumn())

    progress = Progress(*columns, console=console, expand=True, disable=False)
    return progress


def load_model_and_tokenizer(config: Namespace) -> tuple[AutoModelForCausalLM, AutoTokenizer]:
    """Load base model and tokenizer."""
    phi_model_to_path = {
        "phi_1.5B": "microsoft/phi-1_5",
        "phi_2B": "microsoft/phi-2",
        "phi_3_mini_4k": "microsoft/Phi-3-mini-4k-instruct",
        "phi_3_mini_128k": "microsoft/Phi-3-mini-128k-instruct",
        "phi_3.5_mini": "microsoft/Phi-3.5-mini-instruct",
    }

    pythia_model_to_path = {
        "pythia_160m": "EleutherAI/pythia-160m",
        "pythia_70m": "EleutherAI/pythia-70m"
    }

    kwargs = {}

    if hasattr(config, "torch_dtype"):
        if config.torch_dtype == "float16":
            kwargs["torch_dtype"] = torch.float16
        elif config.torch_dtype == "float32":
            kwargs["torch_dtype"] = torch.float32
        else:
            raise ValueError(f"torch_dtype: {config.torch_dtype} not recognized in config file.")

    if config.model in phi_model_to_path:
        model_path = phi_model_to_path[config.model]
        kwargs["pretrained_model_name_or_path"] = model_path
        model = AutoModelForCausalLM.from_pretrained(**kwargs, trust_remote_code=True)
    elif config.model in pythia_model_to_path:
        model_path = pythia_model_to_path[config.model]
        model = GPTNeoXForCausalLM.from_pretrained("EleutherAI/pythia-160m-deduped", trust_remote_code=True)
    else:
        raise ValueError(f'model name "{config.model}" not recognized')

    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)

    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        model.config.pad_token_id = model.config.eos_token_id

    return model, tokenizer


class CustomTrainer(Trainer):
    """
    A custom trainer class for training generative LLMs.
    Allows for the Trainer to have a custom mask token to ignore during loss computation
    as well as a custom attention mask. Assumes that the attention mask is provided by the dataset.
    """

    def __init__(self, *args, train_loader=None, test_loader=None, **kwargs):
        super().__init__(*args, **kwargs)

        if "mask_token" in kwargs:
            self.loss_fn = torch.nn.CrossEntropyLoss(ignore_index=kwargs["mask_token"])
        else:
            self.loss_fn = torch.nn.CrossEntropyLoss()

        self.train_loader = train_loader
        self.test_loader = test_loader

    def get_train_dataloader(self) -> DataLoader:
        return self.train_loader

    def get_eval_dataloader(self, _) -> DataLoader:
        return self.test_loader

    def compute_loss(self, model: nn.Module, inputs: dict, return_outputs=False) -> torch.Tensor:
        """
        Compute the CE loss for the given inputs and labels.
        The labels are shifted to the right by one position for autoregressive models.

        Args:
            model: The language model.
            inputs: A dictionary containing the input tensors, the attention mask and the labels.
            return_outputs (bool, optional): Whether to return the model outputs along with the loss. Defaults to False.

        Returns:
            Union[torch.Tensor, Tuple[torch.Tensor, Any]]: The computed loss, and optionally the model outputs.
        """
        labels = inputs.pop("labels")
        attention_mask = inputs["attention_mask"]
        outputs = model(**inputs)
        labels = labels[..., 1:].contiguous()
        logits = outputs.logits[..., :-1, :].contiguous()
        attention_mask = attention_mask[..., :-1].contiguous()

        # ignore padding tokens when computing the loss
        logits = logits * attention_mask.unsqueeze(-1)

        loss = self.loss_fn(logits.view(-1, logits.shape[-1]), labels.view(-1))

        return (loss, outputs) if return_outputs else loss


def get_optimizer_and_scheduler(params, len_train_dataset, config):
    optimizer = torch.optim.AdamW(
        params=params,
        lr=config.learning_rate,
        betas=(config.adam_beta1, config.adam_beta2),
        eps=config.adam_epsilon,
        weight_decay=config.weight_decay,
    )

    kwargs_lr_scheduler = {
        "optimizer": optimizer,
        "num_warmup_steps": config.num_warmup_steps,
        "num_training_steps": (
            (len_train_dataset - 1) // (config.finetune_train_batch_size * config.gradient_accumulation_steps) + 1
        )
        * config.epochs,
    }
    if config.lr_scheduler_type in ("cosine", "cosine_with_warmup"):
        lr_scheduler = transformers.get_cosine_schedule_with_warmup(**kwargs_lr_scheduler)
    elif config.lr_scheduler_type in ("linear", "linear_with_warmup"):
        lr_scheduler = transformers.get_linear_schedule_with_warmup(**kwargs_lr_scheduler)
    else:
        raise NotImplementedError

    return optimizer, lr_scheduler


class CurriculumTrainer:
    def __init__(
        self,
        predessor: nn.Module,
        successor: nn.Module,
        train_config: Namespace,
        replacement_prob: float = 0.1,
        replacement_rate: float = 0.5,
        k: float = 0.1,
        verbose: bool = True,
    ):
        """Spcialise trainer to train using Bert-of-theseus methodology

        Args:
            predessor (nn.Module): Original model
            successor (nn.Module): Modified model from which we will use
            train_config (Namespace): _description_
            replacement_prob (float, optional): The probability a layer will get replaced. If the scheduler is used this parameter is ignored. Defaults to 0.1.
            replacement_rate (float, optional): The baseline replacement probability to use in the scheduler. Defaults to 0.5.
            k (float, optional): The coeficient used to calculate the probability. This gets multiplied by the current steps so if we want our probability to reach 1 after 100 steps then k=1/100. Defaults to 0.1.
        """
        self.predecessor = predessor
        self.successor = successor
        self.replacement_prob = replacement_prob
        self.replacement_rate = replacement_rate
        self.k = k
        self.train_config = train_config
        self.device = torch.device(train_config.device)
        self.loss = torch.nn.CrossEntropyLoss()

        self.original = deepcopy(self.predecessor)
        self.predecessor.to(self.device)
        self.successor.to(self.device)
        self.original.to(self.device)

        self.logger = logging.getLogger("training")
        if verbose:
            self.logger.setLevel(logging.INFO)

    def prob_scheduler(self, curr_step: int, basic_replacement_rate: float, k: float) -> float:
        dynamic_replacement_rate = min(1, (k * curr_step + basic_replacement_rate))
        return dynamic_replacement_rate

    def train(self, train_loader):
        # We should only update the successor parameters

        self.predecessor.eval()
        self.original.eval()
        self.successor.train()
        optimizer, lr_scheduler = get_optimizer_and_scheduler(
            self.successor.parameters(), len(train_loader), self.train_config
        )

        # freeze the predecessor model
        for name, param in self.predecessor.named_parameters():
            param.requires_grad = False

        # freeze the orignal
        for param in self.original.parameters():
            param.requires_grad = False

        step = 0
        with create_custom_progress_bar(console=console) as pbar:
            total_steps = self.train_config.epochs * len(train_loader)
            prob = self.prob_scheduler(0, self.replacement_rate, self.k)
            task = pbar.add_task(
                "Training",
                total=total_steps,
                loss=100,
                avg_loss=100,
                epoch=0,
                replacement_prob=prob,
                lr=lr_scheduler.get_last_lr()[0],
            )

            for i in range(self.train_config.epochs):
                train_losses = []
                for inputs in train_loader:

                    if self.replacement_rate > 0:
                        prob = self.prob_scheduler(step, self.replacement_rate, self.k)
                        self.replacement_prob = prob

                    input_ids = torch.stack(inputs.pop("input_ids")).transpose(1, 0).to(self.device)

                    optimizer.zero_grad()

                    copied_layers_idxs = []

                    for j in range(3, 5):
                        rand = np.random.rand()
                        if rand < self.replacement_prob:
                            copied_layers_idxs.append(j)
                            self.predecessor.gpt_neox.layers[j] = self.successor.gpt_neox.layers[j]
                            # unfreeze the layer
                            for name, param in self.predecessor.gpt_neox.layers[j].named_parameters():
                                if "lora" in name:
                                    param.requires_grad = True

                    text = inputs.pop("text")
                    labels = torch.stack(inputs.pop("labels")).transpose(1, 0).to(self.device)
                    attention_mask = torch.stack(inputs["attention_mask"]).transpose(1, 0).to(self.device)

                    outputs = self.predecessor(input_ids=input_ids, attention_mask=attention_mask)

                    labels = labels[..., 1:].contiguous()
                    logits = outputs.logits[..., :-1, :].contiguous()
                    attention_mask = attention_mask[..., :-1].contiguous()

                    # ignore padding tokens when computing the loss
                    logits = logits * attention_mask.unsqueeze(-1)

                    loss = self.loss(logits.view(-1, logits.shape[-1]), labels.view(-1))

                    if (
                        len(copied_layers_idxs) > 0
                    ):  # If none of the layers in the model are being trained then calling loss.backward will throw an error
                        self.logger.info(f"{len(copied_layers_idxs)} layers copied to successor")

                        loss.backward()
                        optimizer.step()
                        lr_scheduler.step()

                        train_losses.append(loss.item())

                        self.predecessor.zero_grad()
                        # Reset layers
                        for idx in copied_layers_idxs:
                            self.predecessor.gpt_neox.layers[idx] = self.original.gpt_neox.layers[idx]
                    batch_loss = loss.item()
                    avg_loss = np.mean(train_losses) if len(train_losses) > 0 else 100
                    pbar.update(
                        task,
                        advance=1,
                        loss=batch_loss,
                        avg_loss=avg_loss,
                        epoch=i,
                        replacement_prob=prob,
                        lr=lr_scheduler.get_last_lr()[0],
                    )
                    step += 1

                print(f"Training loss: {np.mean(train_losses)}")
