from phi3_model import Phi3Model, Phi3ForCausalLM, Phi3DecoderLayer
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
import torch
import torch.nn.functional as F
from peft import get_peft_config, LoraConfig, TaskType, get_peft_model
from peft.mapping import inject_adapter_in_model

import numpy as np
import matplotlib.pyplot as plt
import gc
from transformers.utils.logging import disable_progress_bar
import seaborn as sns


def plot_mse_vs_layer(mse_values, output_path, title="MSE vs Layer", xlabel="Layer", ylabel="MSE"):
    """
    Plot MSE values against layer numbers and save the plot to a file.
    
    Parameters:
    mse_values (np.array): 2D array of float values. Each row represents a different line to plot.
    output_path (str): Path where the plot image will be saved.
    title (str): Title of the plot.
    xlabel (str): Label for x-axis.
    ylabel (str): Label for y-axis.
    """
    if not isinstance(mse_values, np.ndarray):
        mse_values = np.array(mse_values)
    
    num_rows, num_layers = mse_values.shape
    
    plt.figure(figsize=(10, 6))
    
    for i in range(num_rows):
        plt.plot(range(1, num_layers + 1), mse_values[i], marker='o')
    
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.grid(True)
    
    # Save the plot to the specified file
    plt.savefig(output_path)
    plt.close()  # Close the figure to free up memory


def check_all_close(model_layer, copied_layer):
    for (mname, mparam),(cname, cparam) in zip(model_layer.named_parameters(),copied_layer.named_parameters()):
        if mname!=cname:
            raise ValueError("Names don't match. Check that layers match")
        if not torch.allclose(mparam.data.cpu(), cparam.data.type(torch.bfloat16).cpu()):
            return False
    return True

class FakeDataset:
    def __init__(self, input_ids):
        self.input_ids = input_ids
        self.limit = input_ids.shape[1]
        self.count = 120

    def __iter__(self):
        return self

    def __next__(self):
        self.count+=1
        if self.count >= self.limit:
            raise StopIteration
        
        # input_ids, labels
        return self.input_ids[:,:self.count-1], self.input_ids[:,self.count-120:self.count]
    
def mse(preds, targs):
    return torch.mean((preds - targs) ** 2)

def calculate_psnr(original, compressed, epsilon=1e-8):
    """
    Calculate PSNR (Peak Signal-to-Noise Ratio) between two PyTorch tensors.
    
    Args:
    original (torch.Tensor): Original image tensor
    compressed (torch.Tensor): Compressed or reconstructed image tensor
    
    Returns:
    float: PSNR value in decibels (dB)
    """
    tensor_without_inf = torch.where(torch.isinf(original), torch.tensor(-float('inf')), original)
    
    # Get the maximum value
    max_value = tensor_without_inf.max()
    
    # Calculate MSE (Mean Squared Error)
    mse = F.mse_loss(compressed, original)
    
    # Calculate PSNR
    psnr = 20 * torch.log10(max_value / (torch.sqrt(mse) + epsilon))
    
    return psnr.item()

def copy_weights(model, mod_model, model_layer_idx, mod_layer_idx):
    layer_dict = {}
    for name, param in model.named_parameters():
        # print(name)
        layer_dict[name] = param

    for name, param in mod_model.named_parameters():
        if f"layers.{mod_layer_idx}.self_attn.o_proj.weight" in name:
            mname = f"model.layers.{model_layer_idx}.self_attn.o_proj.weight"
            param.data.copy_(layer_dict[mname].detach())

        if f"layers.{mod_layer_idx}.self_attn.qkv_proj.weight" in name:
            mname = f"model.layers.{model_layer_idx}.self_attn.qkv_proj.weight"
            param.data.copy_(layer_dict[mname].detach())
            # print("replacing")
        # print(name)
    return mod_model

class ModelModifier:
    def __init__(self, model) -> None:
        self.model = model
        self.layer_dict = {}
        for name, param in self.model.named_parameters():
            # print(name)
            self.layer_dict[name] = param

    def modify(self, mod_model, model_layer_idx, mod_layer_idx):
        for name, param in mod_model.named_parameters():
            if f"layers.{mod_layer_idx}.self_attn.o_proj.weight" in name:
                mname = f"model.layers.{model_layer_idx}.self_attn.o_proj.weight"
                param.data.copy_(self.layer_dict[mname].detach())

            if f"layers.{mod_layer_idx}.self_attn.qkv_proj.weight" in name:
                mname = f"model.layers.{model_layer_idx}.self_attn.qkv_proj.weight"
                param.data.copy_(self.layer_dict[mname].detach())
        return mod_model

def get_mse_per_layer(output,modified_output):
    return [mse(o1, o2).item() for o1,o2 in  zip(output.hidden_states,modified_output.hidden_states)]

def get_psnr_per_layer(output,modified_output):
    return [calculate_psnr(o1, o2) for o1,o2 in  zip(output.hidden_states,modified_output.hidden_states)]

def report_mse_per_layer(output,modified_output):
    all_mse = get_mse_per_layer(output,modified_output)
    all_mse_str = (str(mval) for mval in all_mse)
    print(" | ".join(all_mse_str))
        

def mse_iteration(model, mod_model, input_ids):
    dataset = FakeDataset(input_ids)
    all_mse = []
    # all_psnr = []
    for in_ids, lbl in dataset:
        out = model(input_ids=in_ids, output_hidden_states=True)
        # print(len(out.hidden_states))
        # print(len(model.model.layers))

        mod_out = mod_model(input_ids=in_ids, output_hidden_states=True)
        
        # report_mse_per_layer(out,mod_out)
        all_mse.append(get_mse_per_layer(out,mod_out))
        # all_psnr.append(get_psnr_per_layer(out,mod_out))

    # plot_mse_vs_layer(np.array(all_mse), f"mse_{from_layer}_{to_layer}.png", title=f"MSE vs Layer from:{from_layer} to:{to_layer}", xlabel="Layer", ylabel="MSE")
    # print("here")
    # print(np.mean(all_psnr))
    return all_mse

def plot_heatmap(array, title='Heatmap', output_file='heatmap.png', vmin=0, vmax=20):
    """
    Create and save a heatmap from the given array with a colormap limited between vmin and vmax.
    Values that are 0 are set to np.nan, which will appear as blank spaces in the heatmap.
    """
    # Create a copy of the array to avoid modifying the original
    plot_array = np.copy(array)
    
    # Set 0 values to np.nan
    plot_array[plot_array == 0] = np.nan
    
    plt.figure(figsize=(10, 8))
    sns.heatmap(plot_array, cmap='viridis', annot=False, cbar=True, vmin=vmin, vmax=vmax)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(output_file)
    plt.close()  # Close the figure to free up memory

    

def plot_stored_map():
    # Load the .npy file
    array = np.load("mse.npy")

    # Now use the array with your heatmap function
    plot_heatmap(array, title='Heatmap from NPY', output_file='npy_heatmap.png')

def mse_exploration():
    llm_model_spec = "microsoft/Phi-3.5-mini-instruct"
    device = torch.device("cuda")

    # prepare data
    tokenizer = AutoTokenizer.from_pretrained(llm_model_spec)

    messages = [
        {"role": "system", "content": "You are a helpful AI assistant."},
        {"role": "user", "content": "Can you provide ways to eat combinations of bananas and dragonfruits?"},
        {"role": "assistant", "content": "Sure! Here are some ways to eat bananas and dragonfruits together: 1. Banana and dragonfruit smoothie: Blend bananas and dragonfruits together with some milk and honey. 2. Banana and dragonfruit salad: Mix sliced bananas and dragonfruits together with some lemon juice and honey."},
        {"role": "user", "content": "What about solving an 2x + 3 = 7 equation?"},
        {"role": "assistant", "content": """To solve the equation 2x + 3 = 7, follow these steps: \nStep 1: Isolate the term with the variable (2x) by subtracting 3 from both sides of the equation.\n2x + 3 - 3 = 7 - 3\n2x = 4\nStep 2: Solve for x by dividing both sides of the equation by the coefficient of x, which is 2.\n2x / 2 = 4 / 2\nx = 2\nSo, the solution to the equation 2x + 3 = 7 is x = 2.<|end|>"""},
        ]

    
    print(tokenizer.apply_chat_template(messages, tokenize=False, return_tensors="pt", add_generation_prompt=True))

    input_ids = tokenizer.apply_chat_template(messages, tokenize=True, return_tensors="pt", add_generation_prompt=True)
    current_input_ids = input_ids.clone()
    
    
    disable_progress_bar()

    model = Phi3ForCausalLM.from_pretrained(
            llm_model_spec,
            device_map=device,
            torch_dtype=torch.bfloat16,
            trust_remote_code=True,
        )
    model_modifier = ModelModifier(model)

    mod_model = Phi3ForCausalLM.from_pretrained(
                llm_model_spec,
                device_map=device,
                torch_dtype=torch.bfloat16,
            )

    current_input_ids = current_input_ids.to(model.device)
    
    mse_2d = np.zeros((32, 32))
    for i in range(len(model.model.layers)-1):
        for j in range(i, len(model.model.layers)):
            
            mod_model = model_modifier.modify(mod_model, i,j) # Switch weights in mod_model to the weights of the previous layer on the model
            # mse_list = mse_iteration(model, mod_model, current_input_ids, from_layer=i,to_layer=j)
            mse_list = mse_iteration(model, mod_model, current_input_ids)
            mse_array = np.array(mse_list)
            print(f"From: {i} To: {j} {np.mean(mse_array[mse_array>0])}")

            mse_2d[i,j] = np.mean(mse_array[mse_array>0])
            mod_model = model_modifier.modify(mod_model, j,j) # reset the weights in the mod model
            
    np.save('mse.npy', mse_2d)
    plot_heatmap(mse_2d)

def creater_decoder_layer(model, layer_idx):
    # Creates copy of decoder layer with copied weights
    decoder_layer = Phi3DecoderLayer(model.config,layer_idx=layer_idx)
    layer_dict = {}
    for name, param in decoder_layer.named_parameters():
        print(name)
        print(param.data.mean())
        layer_dict[name] = param

    for name, param in model.model.layers[0].named_parameters():
        # old_weight = param.detach()
        layer_dict[name].data.copy_(param.detach())
        print(f"Layer {name} set to require grad {layer_dict[name].requires_grad}")
    assert check_all_close(model.model.layers[0], decoder_layer)
    return decoder_layer

def main():
    llm_model_spec = "microsoft/Phi-3.5-mini-instruct"
    device = torch.device("cuda")
    model = Phi3ForCausalLM.from_pretrained(
            llm_model_spec,
            device_map=device,
            torch_dtype=torch.bfloat16,
            trust_remote_code=True,
        )
    
    mod_model = Phi3ForCausalLM.from_pretrained(
            llm_model_spec,
            device_map=device,
            torch_dtype=torch.bfloat16,
            trust_remote_code=True,
        )
    
    tokenizer = AutoTokenizer.from_pretrained(llm_model_spec)

    messages = [
        {"role": "system", "content": "You are a helpful AI assistant."},
        {"role": "user", "content": "Can you provide ways to eat combinations of bananas and dragonfruits?"},
        {"role": "assistant", "content": "Sure! Here are some ways to eat bananas and dragonfruits together: 1. Banana and dragonfruit smoothie: Blend bananas and dragonfruits together with some milk and honey. 2. Banana and dragonfruit salad: Mix sliced bananas and dragonfruits together with some lemon juice and honey."},
        {"role": "user", "content": "What about solving an 2x + 3 = 7 equation?"},
        {"role": "assistant", "content": """To solve the equation 2x + 3 = 7, follow these steps: \nStep 1: Isolate the term with the variable (2x) by subtracting 3 from both sides of the equation.\n2x + 3 - 3 = 7 - 3\n2x = 4\nStep 2: Solve for x by dividing both sides of the equation by the coefficient of x, which is 2.\n2x / 2 = 4 / 2\nx = 2\nSo, the solution to the equation 2x + 3 = 7 is x = 2.<|end|>"""},
        ]

    
    print(tokenizer.apply_chat_template(messages, tokenize=False, return_tensors="pt", add_generation_prompt=True))

    input_ids = tokenizer.apply_chat_template(messages, tokenize=True, return_tensors="pt", add_generation_prompt=True)
    print(input_ids)
    current_input_ids = input_ids.clone()
    current_input_ids = current_input_ids.to(model.device)
    print(model)
    # with torch.no_grad():
    #     output = model.generate(
    #         current_input_ids,
    #         max_length=500,
    #         num_return_sequences=1,
    #         temperature=0.0
    #     )
    # generated_text = tokenizer.decode(output[0], skip_special_tokens=False)


    # out = model(input_ids=current_input_ids, output_hidden_states=True)
    # for s in out.hidden_states:
    #     print(s.shape)
    # prob_out = F.softmax(out.logits, dim=-1)
    # Get the predicted classes
    # predicted_input_ids = torch.argmax(prob_out, dim=-1)
    # generated_text = tokenizer.decode(predicted_input_ids.squeeze(), skip_special_tokens=False)
    # print(generated_text)
    # decoder_zero = creater_decoder_layer(model, 0)
    get_hidden_states(model, mod_model, current_input_ids)

    peft_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM, inference_mode=False, r=8, lora_alpha=32, lora_dropout=0.1, target_modules=["o_proj", "qkv_proj"]
    )
    decoder_layer = Phi3DecoderLayer(model.config,layer_idx=0)
    
    peft_decoder_layer = inject_adapter_in_model(peft_config, decoder_layer)

    peft_model = get_peft_model(model, peft_config)
    peft_model.print_trainable_parameters()
    print(peft_model)
    print("here")

    layer_dict = {}
    for name, param in peft_decoder_layer.named_parameters():
        print(name)
        print(param.data.mean())
        layer_dict[name] = param

    # so so deep
    # for name, param in peft_model.model.model.layers[0].named_parameters():
    #     print(name)
    print("--------")
    for name, param in peft_model.model.model.layers[0].named_parameters():
        # old_weight = param.detach()
        layer_dict[name].data.copy_(param.detach())
        print(f"Layer {name} set to require grad {layer_dict[name].requires_grad}")

    assert check_all_close(peft_model.model.model.layers[0], peft_decoder_layer)



# main()
# mse_exploration()
plot_stored_map()