def test_reconstruction_error():
    